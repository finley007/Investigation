Example 2
=========

Overview:
=========
This example will demonstrate how to use Simple Triggers.


Running the Example:
====================
1. Windows users - Modify the example2.bat file (if necessary) 
to set your JAVA_HOME.  Run example2.bat

2. UNIX/Linux users - Modify the example2.sh file (if necessary)
to set your JAVA_HOME.  Execute example2.sh


Configuration Files:
====================
1.  You can decide to specify a log4j.properties file to
control logging output (optional)
